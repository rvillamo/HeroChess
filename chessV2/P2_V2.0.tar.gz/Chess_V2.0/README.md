# HeroChess v2.0 - Spring 2021 - University of California, Irvine
A chess software program. 

This is the 2.0 version of the chess game software. This version integrates chat
functionality. 

To install, be inside the `Chess_V2.0_src` directory and type `make`. For further details, please refer to the INSTALL.md document. Please keep in mind that upon running the server executable, clients must make sure to log in **one at a time**.


Enjoy!


**Defaults:**

* **Server:** zuma.eecs.uci.edu
* **Port #:** 11919
* **Username:** PeaterParker 
* **Password:** AnteaterMan




**Authors:**
* Irania Mazariegos
* Keane Wong
* Paul Lee
* Rachel Villamor



**Update History (MM/DD/YYYY - Description):**

06/06/2021 - Beta/Final Release Version

05/31/2021 - Alpha Release Version
