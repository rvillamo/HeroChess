# Installation Instructions

After unpacking the User/Customer Package, type on the terminal `cd Chess_V2.0` and press enter. 

Finally, type `make` and press enter. Installation is now complete.

To run the game server, type `./bin/HeroChessV2_Server 11919` and press enter.
To run the game client, the clients must type `./bin/HeroChessV2_Client zuma 11919` and press enter.

